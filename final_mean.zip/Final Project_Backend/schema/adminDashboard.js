const { Schema, model} = require("mongoose");

const adminDashboardSchema = new Schema({
    OName : {type: String, required: true},
    OAddress : {type:String , required:true},
    ODateofOrder: {type:Date, default: new Date()},
    OProduct : {type:String , required:true},
    OStatus: {type:String , default : String },
    OsendEmail: {type:String , default : String },
    OEmail : {type:String , required : true }
})

const adminDashboardModel = model("admin",adminDashboardSchema , "adminList" );
module.exports = {adminDashboardSchema, adminDashboardModel}