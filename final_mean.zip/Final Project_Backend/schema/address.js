const { Schema, model} = require("mongoose");

const addressSchema = new Schema({
    email : {type: String, required: true},
    streetAddress : {type: String, required: true},
    city : {type: String, required: true},
    state : {type: String, required: true},
    zipCode: {type:String , required:true}
})

const addressModel = model("address",addressSchema , "address" );
module.exports = {addressSchema, addressModel}