const {Router} = require("express");
const AuthMiddleware = require("../middleware/auth");
const app = Router();
const { orderModel } =  require("../schema/order")

const {APP_SECRET_KEY  }= require("../config")

app.get("/", (req,res)=>{
    try
    {      
        console.log(req.user)
        res.json([])
    }
    catch(error) 
    {
        res.status(401).json(null)
    }   
} )

app.post("/", (req,res)=>{
    try
    {      
        console.log(req.user)
        res.json([])
    }
    catch(error) 
    {
        res.status(401).json(null)
    }   
} )
module.exports = app;
