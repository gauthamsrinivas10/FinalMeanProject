import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, AbstractControl , Validators, EmailValidator} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router'
import IProfile from 'src/app/interface/profile';
import { AddressService } from 'src/app/services/address.service';
import { ProfileService } from 'src/app/services/profile.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  form = new FormGroup({
    firstName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    lastName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    email :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32), Validators.email ])   
  } )
  addressform = new FormGroup({
    email :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    streetAddress :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    city :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    state :new  FormControl('' , [Validators.required , Validators.minLength(2), Validators.maxLength(32) ]),
    zipCode :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ])   
  } )

 
  constructor(private addressService : AddressService , private router : Router , private profileService : ProfileService , private route : ActivatedRoute , private http : HttpClient) { 

      this.profileService.profilebyemail("abc@gmail.com")
      console.log("check working")
  }
  

  ngOnInit(): void {
    
   
    this.addressService.address(this.email?.value , this.streetAddress?.value ,this.city?.value , this.state?.value , this.zipCode?.value);      
    }
    
    checkoutForm(){
      console.log(this.firstName?.value)
      console.log(this.lastName?.value);
      console.log(this.email?.value);
      this.profileService.profile(this.firstName?.value , this.lastName?.value ,this.email?.value);    
     this.router.navigateByUrl("/profile")
      
    
  }



  checkoutAddressForm(){
    console.log(this.addressform.value)
    console.log(this.email?.value);
    console.log(this.streetAddress?.value);
    this.addressService.address(this.email?.value , this.streetAddress?.value ,this.city?.value , this.state?.value , this.zipCode?.value);    
   this.router.navigateByUrl("/profile")
    
  
}
get firstName() : AbstractControl | null {
  return this.form.get("firstName")
}
get lastName() : AbstractControl | null {
  return this.form.get("lastName")
}
get email() : AbstractControl | null {
  return this.form.get("email")
}

get streetAddress() : AbstractControl | null {
  return this.addressform.get("streetAddress")
}

get city() : AbstractControl | null {
  return this.addressform.get("city")
}
get state() : AbstractControl | null {
  return this.addressform.get("state")
}
get zipCode() : AbstractControl | null {
  return this.addressform.get("zipCode")
}

get editForm() {
  return this.addressform
}
}
