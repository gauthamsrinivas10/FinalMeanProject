export default interface IProfile {
    "firstName": string
    "lastName": string   
    "email" : string
    "phone": string   
    "interest": string      
}