export default interface IAddress {
    "email" : string
    "streetAddress": string
    "city": string
    "state": string   
    "zipCode": string
    
}