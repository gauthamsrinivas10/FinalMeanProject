import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

import IAddress from '../interface/address';
import IProfile from '../interface/profile';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  addressInfo : BehaviorSubject<any> = new BehaviorSubject(null);
  constructor(private http : HttpClient , private router : Router) { }
 
  getprofile(email : string) {
    return this.http.post<IProfile>("http://localhost:3001/user/api/v1/profile", email).subscribe((data)=>{
  
      this.addressInfo.next( {city : data.firstName})
      console.log(data);
      this.addressInfo.next( {state : data.lastName})
      this.addressInfo.next( {streetAddress : data.phone})
      this.addressInfo.next( {zipCode : data.interest})
      this.router.navigateByUrl("/Register")
    })

  }

  getprof(email: string) {
    return this.http.get(`http://localhost:3001/user/api/v1/profile/${email}`)
  }

  address(form: IAddress) {
  return this.http.post<IAddress>("http://localhost:3001/user/api/v1/profile",form).subscribe((data)=>{
  
      this.addressInfo.next( {city : data.city})
      this.addressInfo.next( {state : data.state})
      this.addressInfo.next( {streetAddress : data.streetAddress})
      this.addressInfo.next( {zipCode : data.zipCode})
      this.router.navigateByUrl("/checkout")
    })
  }      

  profilebyemail(email: string) {
    return this.http.post<IAddress>("http://localhost:3001/user/api/v1/profilebyemail",email).subscribe((data)=>{
    
        this.addressInfo.next( {city : data.city})
        console.log(data.city);
        this.addressInfo.next( {state : data.state})
        this.addressInfo.next( {streetAddress : data.streetAddress})
        this.addressInfo.next( {zipCode : data.zipCode})
      this.router.navigateByUrl("/checkout")
      
      })
    }    
     
   profile(firstName : string , lastName : string , email : string  ){
    return this.http.post("http://localhost:3001/user/api/v1/profile" , { firstName , lastName, email}).subscribe((data : any)=>{
      window.sessionStorage.setItem("firstName", data.firstName)
      window.sessionStorage.setItem("lastName", data.lastName)
      window.sessionStorage.setItem("email", data.email)      
      this.addressInfo.next( {firstName : data.firstName})
      this.addressInfo.next( {lastName : data.lastName})
      this.addressInfo.next( {email : data.email})      
      this.router.navigateByUrl("/profile")
    
    })
      }  
  
}

