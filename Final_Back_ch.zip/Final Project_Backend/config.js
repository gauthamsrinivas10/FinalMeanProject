const APP_SECRET_KEY = "sfsdfsdfdsdsffdsdffdsfds"
module.exports = {
    APP_SECRET_KEY
}