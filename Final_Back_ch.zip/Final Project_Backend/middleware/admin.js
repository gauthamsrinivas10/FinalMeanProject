async function AdminMiddleware(req, res, next)
{
    console.log(req.user)
    if(req.user && req.user.admin)
    {
        next()
    
    }
    else{
        res.status(401).json({ message : "Only admin users are allowed"})
    }
        

       
}
module.exports = AdminMiddleware;