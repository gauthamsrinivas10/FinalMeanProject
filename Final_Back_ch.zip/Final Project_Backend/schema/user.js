const { Schema, model} = require("mongoose");

const UserSchema = new Schema({
    firstName : {type: String, required: true},
    lastName : {type: String, required: true},
    email : {type: String, required: true},
    password: {type:String , required:true},
    CreatedOn: {type:Date, default: new Date()},
    admin: {type:Boolean, default : false }
})

const UserModel = model("user",UserSchema , "users" );
module.exports = {UserSchema, UserModel}