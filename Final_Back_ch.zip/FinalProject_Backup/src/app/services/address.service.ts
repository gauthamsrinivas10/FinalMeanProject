import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import IAddress from '../interface/address';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  addressInfo : BehaviorSubject<any> = new BehaviorSubject(null);

   constructor(private http : HttpClient , private router : Router) { }
 
   address(email : string , streetAddress : string , city : string , state : string ,zipCode : string ){
 return this.http.post("http://localhost:3001/user/api/v1/address" , { email , streetAddress, city, state , zipCode}).subscribe((data : any)=>{
   window.sessionStorage.setItem("streetAddress", data.streetAddress)
   window.sessionStorage.setItem("city", data.city)
   window.sessionStorage.setItem("state", data.state)
   window.sessionStorage.setItem("zipCode", data.zipCode)
   this.addressInfo.next( {streetAddress : data.streetAddress})
   this.addressInfo.next( {city : data.city})
   this.addressInfo.next( {state : data.state})
   this.addressInfo.next( {zipCode : data.zipCode})
   this.router.navigateByUrl("/profile")
 
 })
   }
}
