import { Component, OnInit } from '@angular/core';
import { default as dataJSON }   from 'src/data.json';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';  

import 'bootstrap/dist/js/bootstrap.bundle';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [NgbCarouselConfig]  // add NgbCarouselConfig to the component providers
  ,styles: [` 
  .img-fluid{ min-width:100%}
  .row{background:lightgray;}
  .description_date, .description_text { padding:5%; }
  `]
})
export class HomeComponent implements OnInit {
  images:any[] = []

  readJSON = dataJSON;
  constructor(config: NgbCarouselConfig) {
    config.interval = 10000;
    config.wrap = false;
    config.keyboard = true;
    config.pauseOnHover = false;

    this.images = this.readJSON.imgArray;
   }

  ngOnInit(): void {
  }

}
