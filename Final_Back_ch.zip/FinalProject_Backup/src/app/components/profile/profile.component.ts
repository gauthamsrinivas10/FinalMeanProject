import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import IAddress from 'src/app/interface/address';
import IProfile from 'src/app/interface/profile';
import { AddressService } from 'src/app/services/address.service';
import { ProfileService } from 'src/app/services/profile.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private profileForm : ProfileService , private addressForm : AddressService , private http : HttpClient ) { }
 
  edit : boolean = false

  profileData = {
    
    firstName:  "",
    lastName : "",    
    email : "",
    phone : "",
    interest : "",
    
    
  }
  addressData = {
    
    streetAddress:  "",
    city : "",    
    state : "",
    zipCode : ""
    
  }


  formaddress!: IAddress; 

  ngOnInit(): void {
console.log(this.profileData.firstName)
  }
  profile(profileData : NgForm){
    this.profileForm.getprofile(this.profileData.email)
    console.log(this.profileData.email);
    }

    // address(addressData : NgForm) {
    //   this.addressForm.address(this.addressData)  
    //   console.log(this.addressData);
    // }

    
    showEdit = false;
    Edit(){
    this.showEdit = true
    }
  
    Save(){
      this.showEdit = false
      window.sessionStorage.setItem("address data", this.addressData.city)
    }
  
   
    }

  



  


  


//   profile(form : NgForm){
//     console.log(this.form, form)
//     this.profileForm.profile<IProfile>(this.form).subscribe(()=>{
// alert("New Profile Update added");
// this.form = {
//   firstName : "",
//   lastName : "",
//   phone : "" ,
//   interest : "",
//   address : ""

// }
    
//   })


//   address(form : NgForm){
//     console.log(this.form, form)
//     this.addressForm.address(this.formaddress).subscribe(()=>{
// alert("New Profile Update added");
// this.formaddress = {
//   streetAddress:  "",
//     city : "",    
//     state : "",
//     zipCode : ""

// }
    
//   })
//   }