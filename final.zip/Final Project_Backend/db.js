const { connect } = require("mongoose");

async function main(){

    const mongourl = "mongodb://localhost:27017/Shop24x7" 
    connect(mongourl)
}
main();