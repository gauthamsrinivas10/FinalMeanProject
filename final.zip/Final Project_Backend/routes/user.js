const {Router} = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
// const app = Router();
const { UserModel } =  require("../schema/user")

const app = Router();
app.use(cors());


const {APP_SECRET_KEY  }= require("../config")
app.post("/api/v1/login", async ( req, res)=>{

    try{
const {body} = req;
const { email, password} = body;

const doc = await UserModel.findOne({email });
if(doc)
{
    console.log(doc);
    const result = await bcrypt.compare(password, doc.password);
    if(result)
    {
        const token = jwt.sign({email}, APP_SECRET_KEY , {expiresIn : 3600})      
  
        res.json({accessToken : token})
    }       
    
    else
    {
        res.status(401).json({message: "Invalid email or/and password"})
    }
}
    

else
{
    res.status(401).json({message: "Invalid email and/or password"})
}

    }
    catch (error){
        res.status(500).json({message: "Internal server error"})
    }
}
)

app.post("/api/v1/register", async (req,res)=>{
    try{
        const {body} = req;
        const {firstName , lastName , email,password} = body
        if( firstName && lastName && email && password && firstName  !== "" && lastName !== "" && email  !== "" && password !== ""){
            const encryptedPassword  = await bcrypt.hash(password, 10)
            const newUser = new UserModel({firstName , lastName ,email, password : encryptedPassword})  
            const doc =  await   newUser.save();          
            const token = jwt.sign({email}, APP_SECRET_KEY , {expiresIn : 3600})   
            res.json({accessToken : token})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
    }
  
})



app.post("/api/v1/profile", async ( req, res)=>{

    try{
const {body} = req;
const { email} = body;

const doc = await UserModel.findOne({email });
if(doc)
{
    console.log(doc);
    res.json(doc)
   
}
    

else
{
    res.status(401).json({message: "Invalid email and/or password"})
}

    }
    catch (error){
        res.status(500).json({message: "Internal server error"})
    }
}
)
module.exports  = app;