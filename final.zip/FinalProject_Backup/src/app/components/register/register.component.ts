import { Component, OnInit , Input } from '@angular/core';
import IRegister from 'src/app/interface/register';
import { RegisterService } from 'src/app/services/register.service';
import { FormControl, FormGroup, AbstractControl , Validators, EmailValidator} from '@angular/forms';
import { Router } from '@angular/router'
import CompareValidator from 'src/app/validators/compare';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form = new FormGroup({
    firstName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    lastName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    email :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32), Validators.email ]),
    password :new  FormControl('', [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),
    confirmpassword :new  FormControl('' , [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),    
  }, [CompareValidator("password" , "confirmpassword")] )

  constructor(private registerform : RegisterService , private router : Router) { }

  ngOnInit(): void {
    this.registerform.register(this.firstName?.value ,this.lastName?.value , this.email?.value , this.password?.value);      
    }
    
  

  registerForm(){
    console.log(this.form.value)
    this.registerform.register(this.firstName?.value ,this.lastName?.value , this.email?.value , this.password?.value);    
alert("New product added");
this.router.navigateByUrl("/profile")
    
  
}
get firstName() : AbstractControl | null {
  return this.form.get("firstName")
}
get lastName() : AbstractControl | null {
  return this.form.get("lastName")
}
get email() : AbstractControl | null {
  return this.form.get("email")
}

get password() : AbstractControl | null {
  return this.form.get("password")
}
get confirmpassword() : AbstractControl | null {
  return this.form.get("confirmpassword")
}

get editForm() {
  return this.form
}
}
