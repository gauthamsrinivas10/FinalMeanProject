import { Injectable } from '@angular/core';
import IRegister from '../interface/register';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

     registerInfo : BehaviorSubject<any> = new BehaviorSubject(null);

   constructor(private http : HttpClient , private router : Router) { }
 
   register(firstName : string , lastName : string , email : string ,password : string ){
 return this.http.post("http://localhost:3001/user/api/v1/register" , { firstName, lastName, email , password}).subscribe((data : any)=>{
   window.sessionStorage.setItem("access-token", data.accessToken)
   this.registerInfo.next( {accessToken : data.accessToken})
   this.router.navigateByUrl("/profile")
 
 })
   }
}
