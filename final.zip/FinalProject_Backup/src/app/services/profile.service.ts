import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

import IAddress from '../interface/address';
import IProfile from '../interface/profile';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  addressInfo : BehaviorSubject<any> = new BehaviorSubject(null);
  constructor(private http : HttpClient , private router : Router) { }
 
  getprofile(email : string) {
    return this.http.post<IProfile>("http://localhost:3001/user/api/v1/profile", email).subscribe((data)=>{
  
      this.addressInfo.next( {city : data.firstName})
      console.log(data);
      this.addressInfo.next( {state : data.lastName})
      this.addressInfo.next( {streetAddress : data.phone})
      this.addressInfo.next( {zipCode : data.interest})
      this.router.navigateByUrl("/Register")
    })

  }
  address(form: IAddress) {
  return this.http.post<IAddress>("http://localhost:3001/user/api/v1/profile",form).subscribe((data)=>{
  
      this.addressInfo.next( {city : data.city})
      this.addressInfo.next( {state : data.state})
      this.addressInfo.next( {streetAddress : data.streetAddress})
      this.addressInfo.next( {zipCode : data.zipCode})
      this.router.navigateByUrl("/")
    })
  }      
       
  
}

