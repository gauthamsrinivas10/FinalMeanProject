export default interface IRegister {
    "firstName": string
    "lastName": string
    "email": string   
    "password": string
    "confirmpassword": string    
}