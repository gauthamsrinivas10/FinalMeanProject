import { Product } from 'src/app/interface/product';

export class Item {

    product!: Product;
    quantity!: number;

}