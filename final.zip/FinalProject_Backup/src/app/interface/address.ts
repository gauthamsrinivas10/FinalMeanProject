export default interface IAddress {
    "streetAddress": string
    "city": string
    "state": string   
    "zipCode": string
    
}